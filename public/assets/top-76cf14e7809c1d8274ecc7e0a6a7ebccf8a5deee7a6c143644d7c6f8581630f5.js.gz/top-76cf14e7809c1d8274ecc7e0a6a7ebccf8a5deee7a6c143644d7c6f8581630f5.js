(function() {
  $(function() {
    return console.log($.fn.tooltip.Constructor.VERSION);
  });

}).call(this);
